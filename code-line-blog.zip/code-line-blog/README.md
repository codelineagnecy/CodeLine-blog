# Code Line Agency Blog - WordPress Plugin

Een moderne blog overzichtspagina plugin voor WordPress, gebouwd met React en geïntegreerd met WordPress REST API.

## Installatie

### Stap 1: Build de React applicatie

Voordat je de plugin kunt gebruiken, moet je eerst de React applicatie builden:

```bash
npm install
npm run build
```

Dit creëert een `dist` folder met de gecompileerde bestanden.

### Stap 2: Plugin installeren

1. Kopieer de hele `wordpress-plugin` folder naar je WordPress `wp-content/plugins/` directory
2. Hernoem de folder naar `code-line-blog`
3. Kopieer de `dist` folder (die je net hebt gebuild) naar de `code-line-blog` plugin folder
4. Activeer de plugin in WordPress admin onder Plugins

### Stap 3: Plugin gebruiken

Er zijn twee manieren om de blog te tonen:

#### Optie 1: Via Shortcode

Voeg de volgende shortcode toe aan een pagina of post:

```
[code_line_blog]
```

#### Optie 2: Via PHP Template

Voeg dit toe aan je theme template:

```php
<?php echo do_shortcode('[code_line_blog]'); ?>
```

## Custom Post Type

De plugin registreert automatisch een custom post type "Blog Artikelen" waar je artikelen kunt aanmaken via WordPress admin.

### Artikel toevoegen

1. Ga naar WordPress admin
2. Klik op "Code Line Blog" in het menu
3. Klik op "Nieuw Artikel"
4. Vul de titel, inhoud, excerpt en uitgelichte afbeelding in
5. Selecteer een categorie
6. Publiceer het artikel

## REST API Endpoints

De plugin biedt de volgende REST API endpoints:

- `GET /wp-json/code-line-blog/v1/articles` - Haal alle artikelen op
- `GET /wp-json/code-line-blog/v1/articles/{id}` - Haal een specifiek artikel op

## Bestandsstructuur

```
code-line-blog/
├── code-line-blog.php    # Hoofd plugin bestand
├── dist/                 # Gebouwde React app (na npm run build)
│   └── assets/
│       ├── index.js
│       └── index.css
└── README.md            # Deze documentatie
```

## WordPress Integratie Features

- ✅ Custom Post Type voor blog artikelen
- ✅ Custom Taxonomy voor categorieën
- ✅ REST API endpoints
- ✅ Shortcode ondersteuning
- ✅ WordPress admin interface
- ✅ Uitgelichte afbeeldingen
- ✅ Responsive design

## Development

Als je wijzigingen maakt aan de React applicatie:

1. Bewerk de bestanden in `/src/app/`
2. Run `npm run build` om opnieuw te builden
3. Kopieer de nieuwe `dist` folder naar de plugin directory
4. Refresh je WordPress pagina

## Systeemvereisten

- WordPress 5.0 of hoger
- PHP 7.4 of hoger
- Modern browser met JavaScript enabled

## Support

Voor vragen of problemen, neem contact op met Code Line Agency.
