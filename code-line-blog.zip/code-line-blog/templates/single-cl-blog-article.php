<?php
if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main class="clb-single">
    <?php while (have_posts()) : the_post(); ?>
        <?php
        $card_excerpt = get_post_meta(get_the_ID(), 'cl_blog_card_excerpt', true);
        $summary = '';
        $author_role = get_the_author_meta('description');
        $primary_category = '';

        $category_terms = get_the_terms(get_the_ID(), 'cl_blog_category');
        if (!empty($category_terms) && !is_wp_error($category_terms)) {
            $primary_category = $category_terms[0]->name;
        } else {
            $wp_categories = get_the_category();
            if (!empty($wp_categories) && !is_wp_error($wp_categories)) {
                $primary_category = $wp_categories[0]->name;
            }
        }

        if (!empty($card_excerpt)) {
            $summary = $card_excerpt;
        } elseif (has_excerpt()) {
            $summary = get_the_excerpt();
        }

        $image_type = get_post_meta(get_the_ID(), 'cl_blog_image_type', true);
        if (!in_array($image_type, array('photo', 'logo'), true)) {
            $image_type = 'photo';
        }
        $is_logo = ($image_type === 'logo');
        ?>
        <article class="clb-single-article">
            <header class="clb-single-header">
                <?php if (!empty($primary_category)) : ?>
                    <p class="clb-single-kicker"><?php echo esc_html(strtoupper($primary_category)); ?></p>
                <?php endif; ?>
                <h1 class="clb-single-title"><?php the_title(); ?></h1>
            </header>

            <?php if (!empty($summary)) : ?>
                <section class="clb-single-summary">
                    <?php echo wp_kses_post(wpautop($summary)); ?>
                </section>
            <?php endif; ?>

            <section class="clb-single-author-block" aria-label="Artikel info">
                <p class="clb-single-updated">Last updated: <?php echo esc_html(get_the_modified_date('j M Y')); ?></p>
                <?php if (!empty($author_role)) : ?>
                    <p class="clb-single-author-role"><?php echo esc_html($author_role); ?></p>
                <?php endif; ?>
            </section>

            <?php if (has_post_thumbnail()) : ?>
                <section class="clb-single-bottom-image <?php echo $is_logo ? 'clb-single-bottom-image-logo' : 'clb-single-bottom-image-photo'; ?>">
                    <?php the_post_thumbnail('full', array('loading' => 'eager')); ?>
                </section>
            <?php endif; ?>

            <section class="clb-single-content">
                <?php the_content(); ?>
            </section>
        </article>
    <?php endwhile; ?>
</main>

<?php
get_footer();
